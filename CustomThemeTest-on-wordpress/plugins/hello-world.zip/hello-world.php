<?php
   /*
   Plugin Name: Hello World
   Plugin URI: #
   Description: Helo World
   Author: Zain Ul Abideen
   Author URI: #
   Version: 0.1  
   */
   
  // Add Shortcode

function hello_world()
{ 
    echo '<hr><b><center>Hello World !!<hr>'; 
}
add_shortcode("shortcode","hello_world");

?>