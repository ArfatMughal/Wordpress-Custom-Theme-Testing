<?php get_header();?>
<?php $First = get_field('1st_banner');?>
<?php $sec = get_field('2nd_banner');?>
<?php $third = get_field('3rd_banner');?>
<?php $AboutTxt = get_field('about');?>
<section class="banner-sec">
   <div class="container">
      <div class="banner-slider">
         <div class="banner-slide">
            <div class="row">
               <div class="col-lg-5">
                  <div class="banner-info">
                     <span><img src="<?php bloginfo('template_directory');?>/images/clock.png" alt=""><?php echo $First['publish_date'];?></span>
                     <h2><?php echo $First['main_title_text'];?></h2>
                     <a href="<?php echo $First['link']?>" title="" class="lnk-default"><?php echo $First['link_text'];?></a>
                  </div>
                  <!--banner-info end-->
               </div>
               <div class="col-lg-7">
                  <div class="banner-img">
                     <img src="<?php bloginfo('template_directory');?>/images/banner-img.jpg" alt="">
                  </div>
                  <!--banner-img end-->
               </div>
            </div>
         </div>
         <!--banner-slide end-->
         <div class="banner-slide">
            <div class="row">
               <div class="col-lg-5">
                  <div class="banner-info">
                     <span><img src="<?php bloginfo('template_directory');?>/images/clock.png" alt=""><?php echo $sec['publish_date'];?></span>
                     <h2><?php echo $sec['main_title_text'];?></h2>
                     <a href="<?php echo $sec['link']?>" title="" class="lnk-default"><?php echo $sec['link_text'];?></a>
                  </div>
                  <!--banner-info end-->
               </div>
               <div class="col-lg-7">
                  <div class="banner-img">
                     <img src="<?php bloginfo('template_directory');?>/images/banner-img2.jpg" alt="">
                  </div>
                  <!--banner-img end-->
               </div>
            </div>
         </div>
         <!--banner-slide end-->
         <div class="banner-slide">
            <div class="row">
               <div class="col-lg-5">
                  <div class="banner-info">
                     <span><img src="<?php bloginfo('template_directory');?>/images/clock.png" alt=""><?php echo $third['publish_date'];?></span>
                     <h2><?php echo $third['main_title_text'];?></h2>
                     <a href="<?php echo $third['link']?>" title="" class="lnk-default"><?php echo $third['link_text'];?></a>
                  </div>
                  <!--banner-info end-->
               </div>
               <div class="col-lg-7">
                  <div class="banner-img">
                     <img src="<?php bloginfo('template_directory');?>/images/banner-img3.jpg" alt="">
                  </div>
                  <!--banner-img end-->
               </div>
            </div>
         </div>
         <!--banner-slide end-->
      </div>
      <!--banner-slider end-->
   </div>
</section>
<!--banner-sec end-->
<section class="main-content">
   <div class="container">
      <div class="about-us">
         <h3>About Us</h3>
         <p><?php echo $AboutTxt['about_text_area'];?></p>
      </div>
      <!--about-us end-->
      <div class="blog-section">
         <h3>Our News</h3>
      </div>
      <?php 
         // the query
         $the_query = new WP_Query( array('post_type' => 'news')); ?>
      <?php if ( $the_query->have_posts() ) : ?>
      <!-- pagination here -->
      <!-- the loop -->
      <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
      <div class="blog-section">
         <div class="blog-posts">
            <div class="blog-post">
               <div class="post-img">
                  <?php if( has_post_thumbnail() ): 
                     the_post_thumbnail('thumbnail'); 
                     endif; ?>
               </div>
               <!--post-img end-->
               <div class="post-info">
                  <span class="posted-date"><?php the_time('j F, Y')?></span>
                  <p><?php the_content();?></p>
               </div>
               <!--post-info end-->
            </div>
            <!--blog-post end-->
         </div>
         <br>
         <!--blog-posts end-->
      </div>
      <?php endwhile; ?>
      <!-- end of the loop -->
      <?php wp_reset_postdata(); ?>
      <?php else : ?>
      <p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
      <?php endif; ?> 
      <!--blog-section end-->
      <div class="clearfix"></div>
   </div>
</section>
<!--main-content end-->
<?php get_footer();?>