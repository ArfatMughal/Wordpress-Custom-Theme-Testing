<?php 

// Silence is gold

?>