<?php 
/* template Name: About Us */
get_header();
?>
<div class="container">
	<div class="header">
		<img src="<?php header_image(); ?>" height="300px" width="1350px" alt="" />
	</div>
		<h1 align="center" style="background:url('<? the_post_thumbnail_url();?>') !important;"><?php the_title();?></h1>
			<p><?php the_content();?></p>

</div>
<?php get_footer();?>